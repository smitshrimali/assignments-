import React, { useContext } from "react";
import { Link } from "react-router";
import { ToggleContext } from "./ToggleContext";

const Navbar = () => {

  const {theme, toggleTheme}=useContext(ToggleContext);

  // console.log(theme);
  

  return (
    <nav className="navbar navbar-expand-lg bg-body-tertiary" style={{position:"fixed", top:0, width:"100%", zIndex:111}}>
      <div className="container-fluid">
        <Link className="navbar-brand" to={"/"}>
          Navbar
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link active" aria-current="page" to={"/"}>
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to={"/about"}>
                About
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to={"/contact"}>
                Contact
              </Link>
            </li>
            <li className="nav-item">
              <button onClick={()=>toggleTheme(theme === "light" ? "dark":"light")}> {theme === "light" ? "Dark":"Light"}  </button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
